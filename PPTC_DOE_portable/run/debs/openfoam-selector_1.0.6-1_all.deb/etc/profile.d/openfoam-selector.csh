# -*- sh -*-
# Copyright (c) 2007 Cisco Systems, Inc.  All rights reserved.
# Copyright (C) 2018 OpenCFD Ltd.
#
# File installed for C-shell startups to select which OPENFOAM
# installation to use.  Not using "alternatives" because we want to be
# able to set per-user level defaults, not just system-wide defaults.

set openfoam_selector_dir="/var/openfoam-selector/data"
set openfoam_selector_homefile="$HOME/.openfoam-selector"
set openfoam_selector_sysfile="/etc/openfoam/openfoam-selector"

# The selection name
set openfoam_selection=
if ( -f "$openfoam_selector_homefile" ) then
    set openfoam_selection=`cat $openfoam_selector_homefile`
else if ( -f "$openfoam_selector_sysfile" ) then
    set openfoam_selection=`cat $openfoam_selector_sysfile`
endif

# 1st: get selection name -> directory name correspondence
if ("$openfoam_selection" != "" && -f "$openfoam_selector_dir/$openfoam_selection") then
    openfoam_selection=`cat "$openfoam_selector_dir/$openfoam_selection"`

    # 2nd: test for and source OpenFOAM etc/cshrc
    if ("$openfoam_selection" != "" && -f "$openfoam_selection/etc/cshrc") then
        source "$openfoam_selection/etc/cshrc"
    endif
endif

# -----------------------------------------------------------------------------
